#!/bin/bash/env python

print "picoCTF{%s}" % int("dGg0dF93NHNfczFtcEwz",2)

